
package caballo;


public class Competidor {
    Persona jockey;
    Caballo caballo;
    int position;
    int tiempo;

    public Competidor(Persona jockey, Caballo caballo, int position, int tiempo) {
        this.jockey = jockey;
        this.caballo = caballo;
        this.position = position;
        this.tiempo = tiempo;
    }

    public Persona getJockey() {
        return jockey;
    }

    public void setJockey(Persona jockey) {
        this.jockey = jockey;
    }

    public Caballo getCaballo() {
        return caballo;
    }

    public void setCaballo(Caballo caballo) {
        this.caballo = caballo;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public int getTiempo() {
        return tiempo;
    }

    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }
    
    


    
}
